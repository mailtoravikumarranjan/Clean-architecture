﻿using Clean.Model;
using Clean.Utility.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using static Clean.Model.Contactus;

namespace Clean.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactusController : Controller
    {
        private readonly IContactUsServices contactService;
        public ContactusController(IContactUsServices contactService)
        {
            this.contactService = contactService;
        }
        [HttpGet]
        [Route("")]
        public IActionResult GetContactUs()
        {
            return Ok(this.contactService.GetAllContactUs());
        }
        [HttpGet]
        [Route("{id}")]
        public ContactUs GetContactById(int id)
        {
            return contactService.GetContactUs(id);
        }

        [HttpPost]
        [Route("")]
        [AllowAnonymous]
        public void AddContactUs([FromBody] ContactUs ContactUs)
        {
              contactService.insertContactus(ContactUs);
        }
           

        [HttpDelete]
        [Route("{id}")]
        [AllowAnonymous]
        public void DeleteContactUs(int id)
        {
            contactService.DeleteContactus(id);
        }
    }
}
