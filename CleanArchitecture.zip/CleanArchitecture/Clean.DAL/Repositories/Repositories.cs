﻿using Clean.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clean.DAL.Repositories
{
    public class Repositories<T> : IRepositories<T> where T : BaseEntity
    {
        private readonly DataContext _context;
        private readonly DbSet<T> _entities;
        public Repositories(DataContext context)
        {
            _context = context;
            _entities = context.Set<T>();
        }
        
        public async Task<T> Add(T entity)
        {
            if(entity==null)
            throw new NotImplementedException();

            await _entities.AddAsync(entity);
            await _context.SaveChangesAsync();

            return entity;
        }

        public Task<int> Delete(int id)
        {
            if(id==null)
            throw new NotImplementedException();

            T enitity = _entities.SingleOrDefault(x=>x.Id==id);
            if(enitity==null)
                return Task.FromResult(id);
            _entities.Remove(enitity);
            _context.SaveChangesAsync();
            return Task.FromResult(id);
        }

        public async  Task<IEnumerable<T>> GetAll()
        {
           return await _entities.ToListAsync();

        }

        public async Task<T?> GetById(int id)
        {
          return await _entities.SingleOrDefaultAsync(x=>x.Id==id);
        }

        public async Task<T> Update(T entity)
        {
            if(entity==null)
            throw new NotImplementedException();
            await _context.SaveChangesAsync();
            return entity;
        }
    }
}
