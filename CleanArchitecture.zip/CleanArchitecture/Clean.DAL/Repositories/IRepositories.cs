﻿using Clean.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clean.DAL.Repositories
{
    public interface IRepositories<T> where T : BaseEntity
    {
        Task<T> Add(T entity);
        Task<T> Update(T entity);
        Task<int> Delete(int id);
        Task<T?> GetById(int id);
        Task<IEnumerable<T>> GetAll();
    }
}
