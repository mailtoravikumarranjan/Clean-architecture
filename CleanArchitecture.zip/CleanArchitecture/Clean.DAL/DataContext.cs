﻿using Clean.Model;
using Microsoft.EntityFrameworkCore;
using static Clean.Model.Contactus;
namespace Clean.DAL
{
    public class DataContext : DbContext
    {
        protected DataContext()
        {
        }

        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("DB Connection String");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            base.OnModelCreating(modelBuilder);
            new ContactMap(modelBuilder.Entity<ContactUs>());

            
        }
     


    }
}
