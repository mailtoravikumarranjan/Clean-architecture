﻿using Clean.DAL.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Clean.Model.Contactus;

namespace Clean.Utility.Services
{
    public class ContactUsServices : IContactUsServices
    {
        private readonly IRepositories<ContactUs> _contactUsRepository;
        public ContactUsServices(IRepositories<ContactUs> contactUsRepository)
        {
            _contactUsRepository = contactUsRepository;
        }
        public void DeleteContactus(int id)
        {
            this._contactUsRepository.Delete(id);
        }

        public async Task<IEnumerable<ContactUs>> GetAllContactUs()
        {
           return await  this._contactUsRepository.GetAll();
        }

        public ContactUs GetContactUs(int id)
        {
            return this._contactUsRepository.GetById(id).Result;
        }

        public void insertContactus(ContactUs obj)
        {
             this._contactUsRepository.Add(obj);
        }

        public void UpdateContactus(ContactUs obj)
        {
            this._contactUsRepository.Update(obj);
        }
    }
}
