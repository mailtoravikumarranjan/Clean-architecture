﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Clean.Model.Contactus;

namespace Clean.Utility.Services
{
    public interface IContactUsServices
    {
        Task<IEnumerable<ContactUs>> GetAllContactUs();
        ContactUs GetContactUs(int id);
        void insertContactus(ContactUs obj);
        void UpdateContactus(ContactUs obj);
        void DeleteContactus(int id);
    }
}
