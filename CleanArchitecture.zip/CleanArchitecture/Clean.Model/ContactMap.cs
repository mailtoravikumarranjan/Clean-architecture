﻿using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Clean.Model.Contactus;

namespace Clean.Model
{
    public class ContactMap
    {
        public ContactMap(EntityTypeBuilder<ContactUs> entityBuilder)
        {

            entityBuilder.HasKey(p => p.Id);
        }
    }
}
