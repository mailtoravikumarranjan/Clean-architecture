﻿using System.ComponentModel.DataAnnotations;

namespace Clean.Model
{
    public class Contactus
    {
        public class ContactUs : BaseEntity
        {
            [EmailAddress]
            [Required(ErrorMessage = "Email Id is required")]
            public string email { get; set; }

            [Required(ErrorMessage = "Mobile is required")]
            public long mobile { get; set; }
            [Required(ErrorMessage = "Please select Query Related to Option ")]
            public string QueryRelated { get; set; }
            [DataType(DataType.MultilineText)]
            [Required]
            public string Message { get; set; }
        }
    }
}
